#include <stdio.h>

int main(int argc, char** argv) {

    double x, y = 0.0;
    double a = 1.0;
    double b = 1.0;
    
    for(int i = 0; i < 10; i++) {

        double xTemp = x*x - y*y + a;
        double yTemp = 2*x*y + b;
        x = xTemp;
        y = yTemp;

        printf("iteration: %d\nx: %f, y: %f\n", i + 1, x, y);
    }

    
}